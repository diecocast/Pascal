<!DOCTYPE html>
<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>Plataforma Pascal NV: Log in to the site</title>
    <link rel="shortcut icon" href="https://www.plataformapascal.com/NV/theme/image.php/lambda/theme/1610135029/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Plataforma Pascal NV: Log in to the site" />
<link rel="stylesheet" type="text/css" href="https://www.plataformapascal.com/NV/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://www.plataformapascal.com/NV/theme/styles.php/lambda/1610135029_1/all" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/www.plataformapascal.com\/NV","sesskey":"ZLBi5DFXDj","themerev":"1610135029","slasharguments":1,"theme":"lambda","iconsystemmodule":"core\/icon_system_standard","jsrev":"1610057684","admin":"admin","svgicons":true,"usertimezone":"America\/Bogota","contextid":1};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/www.plataformapascal.com\/NV\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/www.plataformapascal.com\/NV\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/www.plataformapascal.com\/NV\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/www.plataformapascal.com\/NV\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/www.plataformapascal.com\/NV\/theme\/yui_combo.php?m\/1610057684\/","combine":true,"comboBase":"https:\/\/www.plataformapascal.com\/NV\/theme\/yui_combo.php?","ext":false,"root":"m\/1610057684\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-checknet":{"requires":["base-base","moodle-core-notification-alert","io-base"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader","moodle-core-event"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-course-modchooser":{"requires":["moodle-core-chooserdialogue","moodle-course-coursebase"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-formatchooser":{"requires":["base","node","node-event-simulate"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-form-showadvanced":{"requires":["node","base","selector-css3"]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-qbankmanager":{"requires":["node","selector-css3"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_forum-subscriptiontoggle":{"requires":["base-base","io-base"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-repaginate":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_grader-gradereporttable":{"requires":["base","node","event","handlebars","overlay","event-hover"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-alert","moodle-core-notification-warning","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_html-button":{"requires":["promise","moodle-editor_atto-plugin","moodle-atto_html-beautify","moodle-atto_html-codemirror","event-valuechange"]},"moodle-atto_html-codemirror":{"requires":["moodle-atto_html-codemirror-skin"]},"moodle-atto_html-beautify":{},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin","moodle-form-shortforms"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_recordrtc-recording":{"requires":["moodle-atto_recordrtc-button"]},"moodle-atto_recordrtc-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_recordrtc-recording"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/www.plataformapascal.com\/NV\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/www.plataformapascal.com\/NV\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1610057684\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/www.plataformapascal.com\/NV\/lib\/javascript.php\/1610057684\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/www.plataformapascal.com\/NV\/lib\/javascript.php\/1610057684\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]},"mathjax":{"name":"mathjax","fullpath":"https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/mathjax\/2.7.2\/MathJax.js?delayStartupUntil=configured"}}};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta name="robots" content="noindex" />    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google web fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400%7COpen+Sans:700" rel="stylesheet">

</head>

<body  id="page-login-index" class="format-site  path-login dir-ltr lang-en yui-skin-sam yui3-skin-sam www-plataformapascal-com--NV pagelayout-login course-1 context-1 notloggedin  has-region-footer-left used-region-footer-left has-region-footer-middle used-region-footer-middle has-region-footer-right used-region-footer-right" >

<div class="skiplinks">
    <a href="#maincontent" class="skip">Skip to main content</a>
</div><script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js"></script><script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/jquery.php/core/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/jquery.php/theme_lambda/jquery.easing.min.1.4.js"></script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/jquery.php/theme_lambda/scripts.js"></script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/jquery.php/theme_lambda/camera.js"></script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/jquery.php/theme_lambda/bxslider.js"></script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/lib/javascript.php/1610057684/lib/javascript-static.js"></script>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>


<div id="wrapper" >



<header id="page-header" class="clearfix">              	
		<div class="container-fluid">    
	<div class="row-fluid">

				<div class="span6">
			<div class="logo-header">
				<a class="logo" href="https://www.plataformapascal.com/NV" title="Home">
					<img src="//www.plataformapascal.com/NV/pluginfile.php/1/theme_lambda/logo/1610135029/logoNV3.png" class="img-responsive" alt="logo" />				</a>
			</div>
		</div>
		      	

		<div class="span6 login-header">
			<div class="profileblock">

				
				<form class="navbar-form pull-right" method="post" action="https://www.plataformapascal.com/NV/login/index.php?authldap_skipntlmsso=1">
						<div id="block-login">
							<div id="user"><i class="fa fa-user"></i></div>
							<label for="inputName" class="lambda-sr-only">Username</label>
							<input type="hidden" name="logintoken" value="yYEUZT36GlWXASuMdbx9X40MJ5AApTEF" />							<input id="inputName" class="span2" type="text" name="username" placeholder="Username">
								<div id="pass"><i class="fa fa-key"></i></div>
								<label for="inputPassword" class="lambda-sr-only">Password</label>
								<input id="inputPassword" class="span2" type="password" name="password" placeholder="Password">
									<button type="submit" id="submit"><span class="lambda-sr-only">Log in</span></button>
								</div>

								<div class="forgotpass">
									 
								</div>

							</form>
							
							
						</div>
					</div>

				</div>
			</div>               
</header>
<header class="navbar">
    <nav class="navbar-inner">
        <div class="lambda-custom-menu container-fluid">
            <a class="brand" href="https://www.plataformapascal.com/NV">PascalNV</a>            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="nav-collapse collapse">
                <ul class="nav"><li class="dropdown"><a href="#cm_submenu_1" class="dropdown-toggle" data-toggle="dropdown" title="Boletines de Notas">Boletines de Notas<b class="caret"></b></a><ul class="dropdown-menu"><li><a title=" Primaria" href="https://colegiopascal.net/ColegioWeb/html/buscar.htm"> Primaria</a></li><li><a title=" Sexto a Noveno" href="https://colegiopascal.net/ColegioWeb/html/buscar.htm"> Sexto a Noveno</a></li><li><a title=" Décimo y Once" href="https://colegiopascal.net/ColegioWeb2/html/buscar.htm"> Décimo y Once</a></li></ul><li class="dropdown"><a href="#cm_submenu_2" class="dropdown-toggle" data-toggle="dropdown" title="Herramientas">Herramientas<b class="caret"></b></a><ul class="dropdown-menu"><li><a title="Proyecto Newton" href="http://colegiopascal.com/newton.shtml">Proyecto Newton</a></li><li><a title="Tabla Periódica" href="https://www.fishersci.es/es/es/periodic-table.html">Tabla Periódica</a></li></ul><li class="dropdown"><a href="#cm_submenu_3" class="dropdown-toggle" data-toggle="dropdown" title="Directorio Turores">Directorio Turores<b class="caret"></b></a><ul class="dropdown-menu"><li><a title="Bachillerato" href="https://drive.google.com/file/d/1smuwmGesDLQayOdX8PbVg_17Ef9rtCEX/view?usp=sharing">Bachillerato</a></li><li><a title="Primaria" href="https://drive.google.com/file/d/1hAKjYAQIk4dKV3cgvR13ClPTrtRe4zgm/view?usp=sharing">Primaria</a></li></ul><li class="dropdown"><a href="#cm_submenu_4" class="dropdown-toggle" data-toggle="dropdown" title="Horarios de clase">Horarios de clase<b class="caret"></b></a><ul class="dropdown-menu"><li><a title="Sexto" href="https://drive.google.com/file/d/1LGtxjt6sJbgUGLKMkU5X_KCNcjjNVYTL/view?usp=sharing">Sexto</a></li><li><a title="Séptimo" href="https://drive.google.com/file/d/10INp-U13hzjnWEFavdL7PltDvdD7mZ4m/view?usp=sharing">Séptimo</a></li><li><a title="Octavo" href="https://drive.google.com/file/d/1AlL3gmVmIi8Do8FM8pWLZLXJZA577_-r/view?usp=sharing">Octavo</a></li><li><a title="Noveno" href="https://drive.google.com/file/d/1Ntm8e-bGniM7NcXbWNZpF8V7hWDuKfJN/view?usp=sharing">Noveno</a></li><li><a title="Décimo" href="https://drive.google.com/file/d/1CssIkjIEaD41uhWcCipAGlwCL9nQEVZu/view?usp=sharing">Décimo</a></li><li><a title="Undécimo" href="https://drive.google.com/file/d/1qD6uJoVOHR2Pfh91JPDoRP37VQECg71y/view?usp=sharing">Undécimo</a></li></ul><li class="dropdown langmenu"><a href="" class="dropdown-toggle" data-toggle="dropdown" title="Language">English ‎(en)‎<b class="caret"></b></a><ul class="dropdown-menu"><li><a title="English ‎(en)‎" href="https://www.plataformapascal.com/NV/login/index.php?lang=en">English ‎(en)‎</a></li><li><a title="Español - Colombia ‎(es_co)‎" href="https://www.plataformapascal.com/NV/login/index.php?lang=es_co">Español - Colombia ‎(es_co)‎</a></li><li><a title="Español - Internacional ‎(es)‎" href="https://www.plataformapascal.com/NV/login/index.php?lang=es">Español - Internacional ‎(es)‎</a></li></ul></ul>                <ul class="nav pull-right">
                    <li></li>
                </ul>
                
                                
                                <form id="search" action="https://www.plataformapascal.com/NV/course/search.php" >
                	<label for="coursesearchbox" class="lambda-sr-only">Search courses</label>						
					<input id="coursesearchbox" type="text" onFocus="if(this.value =='Search courses' ) this.value=''" onBlur="if(this.value=='') this.value='Search courses'" value="Search courses" name="search" >
					<button type="submit"><span class="lambda-sr-only">Submit</span></button>						
				</form>
                                
            </div>
        </div>
    </nav>
</header>


<div id="page" class="container-fluid" >

    <div id="page-content" class="row-fluid">
        <section id="region-main" class="span12">
        
            <span class="notifications" id="user-notifications"></span><div role="main"><span id="maincontent"></span><div class="loginbox clearfix onecolumn">

    <div class="loginpanel">

        <h2>Log in</h2>

        <div class="subcontent loginsub">
            <form action="https://www.plataformapascal.com/NV/login/index.php" method="post" id="login">
                <div class="loginform">
                    <div class="form-label">
                        <label for="username">
                                Username
                        </label>
                    </div>
                    <div class="form-input">
                        <input type="text" name="username" id="username" size="15" value="" autocomplete="username">
                    </div>
                    <div class="clearer"><!-- --></div>
                    <div class="form-label">
                        <label for="password">Password</label>
                    </div>
                    <div class="form-input">
                        <input type="password" name="password" id="password" size="15" value="" autocomplete="current-password">
                    </div>
                </div>

                <div class="clearer"><!-- --></div>
                    <div class="rememberpass">
                        <input type="checkbox" name="rememberusername" id="rememberusername" value="1"  />
                        <label for="rememberusername">Remember username</label>
                    </div>
                <div class="clearer"><!-- --></div>
                <input id="anchor" type="hidden" name="anchor" value="" />
                <script>document.getElementById('anchor').value = location.hash;</script>
                <input type="hidden" name="logintoken" value="yYEUZT36GlWXASuMdbx9X40MJ5AApTEF">
                <input type="submit" id="loginbtn" value="Log in" />
                <div class="forgetpass">
                    <a href="https://www.plataformapascal.com/NV/login/forgot_password.php">Forgotten your username or password?</a>
                </div>
            </form>

            <div class="desc">
                Cookies must be enabled in your browser
                <span class="helptooltip">
    <a href="https://www.plataformapascal.com/NV/help.php?component=moodle&amp;identifier=cookiesenabled&amp;lang=en" title="Help with Cookies must be enabled in your browser" aria-haspopup="true" target="_blank"><img class="icon iconhelp" alt="Help with Cookies must be enabled in your browser" title="Help with Cookies must be enabled in your browser" src="https://www.plataformapascal.com/NV/theme/image.php/lambda/core/1610135029/help" /></a>
</span>
            </div>

        </div>

            <div class="subcontent guestsub">
                <div class="desc">Some courses may allow guest access</div>
                <form action="https://www.plataformapascal.com/NV/login/index.php" method="post" id="guestlogin">
                    <div class="guestform">
                        <input type="hidden" name="logintoken" value="yYEUZT36GlWXASuMdbx9X40MJ5AApTEF">
                        <input type="hidden" name="username" value="guest" />
                        <input type="hidden" name="password" value="guest" />
                        <input type="submit" value="Log in as a guest" />
                    </div>
                </form>
            </div>

    </div>

    <div class="signuppanel">

        <div class="subcontent potentialidps">
            <h6>Log in using your account on:</h6>
            <div class="potentialidplist">
                    <div class="potentialidp">
                        <a href="https://www.plataformapascal.com/NV/auth/oauth2/login.php?id=5&amp;wantsurl=%2F&amp;sesskey=ZLBi5DFXDj" title="Google" class="btn">
                            <img src="https://accounts.google.com/favicon.ico" alt="" width="24" height="24"/>
                        Google
                        </a>
                    </div>
            </div>
        </div>
    </div>
</div></div>        </section>
    </div>
    
    <a href="#top" class="back-to-top"><span class="lambda-sr-only">Back</span></a>
    
</div>

	<footer id="page-footer" class="container-fluid" >
			<div class="row-fluid">
		<aside id="block-region-footer-left" class="span4 block-region" data-blockregion="footer-left" data-droptarget="1"><a class="skip skip-block" id="fsb-1" href="#sb-1">Skip Plataforma Pascal</a><div id="inst58" class="block_html  block" role="complementary" data-block="html" data-instanceid="58" aria-labelledby="instance-58-header" data-dockable="1"><div class="header"><div class="title"><div class="block_action"></div><h2 id="instance-58-header">Plataforma Pascal</h2></div></div><div class="content"><div class="no-overflow"><h5><b>CENTRO EDUCATIVO NUEVA VISION</b></h5>
<address>Cra 5 # 50A-152 Barranquilla - Colombia</address>
<i class="fa fa-mobile fa-mobile-alt fa-lg"></i> Teléfono : (057) 3132422040<br>
<i class="fa fa-envelope"></i> E-mail: <a href="info@cenuevavision.com">info@cenuevavision.com</a>
<i class="fa fa-envelope"></i> E-mail: <a href="info@plataformapascal.com">info@plataformapascal.com</a>
<h6>Contactenos:</h6>
<div class="social_icons pull-right">
    <a class="social fa fab fa-facebook" target="_blank" href="https://www.facebook.com/plataformapascal"> </a>
    <a class="social fa fab fa-twitter" target="_blank" href="https://twitter.com/platpascal"> </a>
    <a class="social fa fab fa-instagram" target="_blank" href="https://www.instagram.com/plataformapascal/"> </a>
    <a class="social fa fab fa-youtube" target="_blank" href="https://www.youtube.com/channel/UCQmIwX5ss8b5KKJ4L_2zVcw"> </a>
</div></div></div></div><span class="skip-block-to" id="sb-1"></span><div id="inst61" class="block_html  block" role="complementary" data-block="html" data-instanceid="61" aria-label="HTML"><div class="content"><div class="block_action notitle"></div><div class="no-overflow">(c) 2021 | Derechos Reservados Fundación Pascal
<p><br></p></div></div></div></aside><aside id="block-region-footer-middle" class="span4 block-region" data-blockregion="footer-middle" data-droptarget="1"><a class="skip skip-block" id="fsb-3" href="#sb-3">Skip Nuestra Filosofía</a><div id="inst59" class="block_html  block" role="complementary" data-block="html" data-instanceid="59" aria-labelledby="instance-59-header" data-dockable="1"><div class="header"><div class="title"><div class="block_action"></div><h2 id="instance-59-header">Nuestra Filosofía</h2></div></div><div class="content"><div class="no-overflow"><blockquote>
  <p>Aportar valor mediante la innovación es nuestra meta.</p>
  <footer><cite title="Centro Educativo Nueva Visión">Centro Educativo Nueva Visión</cite></footer>
</blockquote></div></div></div><span class="skip-block-to" id="sb-3"></span></aside><aside id="block-region-footer-right" class="span4 block-region" data-blockregion="footer-right" data-droptarget="1"><a class="skip skip-block" id="fsb-4" href="#sb-4">Skip Calendar</a><div id="inst57" class="block_calendar_month  block" role="complementary" data-block="calendar_month" data-instanceid="57" aria-labelledby="instance-57-header" data-dockable="1"><div class="header"><div class="title"><div class="block_action"></div><h2 id="instance-57-header">Calendar</h2></div></div><div class="content"><div id="calendar-month-2022-March-621f6b92b5a0d621f6b92b5c0b1"  data-template="core_calendar/month_mini"  data-includenavigation="false" data-mini="true">
    <div id="month-mini-2022-March-621f6b92b5a0d621f6b92b5c0b1" class="calendarwrapper" data-courseid="1" data-categoryid="0" data-month="3" data-year="2022" data-view="month">
        <span class="overlay-icon-container hidden" data-region="overlay-icon-container">
            <span class="loading-icon icon-no-margin"><img class="icon " alt="Loading" title="Loading" src="https://www.plataformapascal.com/NV/theme/image.php/lambda/core/1610135029/i/loading" /></span>
        </span>
        <table class="minicalendar calendartable">
            <caption class="calendar-controls">
                    <h3>
                        <a href="https://www.plataformapascal.com/NV/calendar/view.php?view=month&time=1646226322" title="This month">March 2022</a>
                    </h3>
            </caption>
            <thead>
              <tr>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Sunday">Sun</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Monday">Mon</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Tuesday">Tue</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Wednesday">Wed</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Thursday">Thu</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Friday">Fri</abbr>
                    </th>
                    <th class="header text-xs-center" scope="col">
                        <abbr title="Saturday">Sat</abbr>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr data-region="month-view-week">
                        <td class="dayblank">&nbsp;</td>
                        <td class="dayblank">&nbsp;</td>
                        <td class="day text-center" data-day-timestamp="1646110800">
                                1
                            </td>
                        <td class="day text-center today" data-day-timestamp="1646197200">
                                    <a  href="https://www.plataformapascal.com/NV/calendar/view.php?view=day&amp;time=1646197200" id="calendar-day-popover-link-1-2022-60-621f6b92b5a0d621f6b92b5c0b1" data-container="body" data-toggle="popover" data-html="true" data-trigger="hover" data-placement="top" data-title="Today Wednesday, 2 March" data-alternate="No events">2</a>
    <div class="hidden">
        
    </div>
                            </td>
                        <td class="day text-center" data-day-timestamp="1646283600">
                                3
                            </td>
                        <td class="day text-center" data-day-timestamp="1646370000">
                                4
                            </td>
                        <td class="day text-center weekend" data-day-timestamp="1646456400">
                                5
                            </td>
                </tr>
                <tr data-region="month-view-week">
                        <td class="day text-center weekend" data-day-timestamp="1646542800">
                                6
                            </td>
                        <td class="day text-center" data-day-timestamp="1646629200">
                                7
                            </td>
                        <td class="day text-center" data-day-timestamp="1646715600">
                                8
                            </td>
                        <td class="day text-center" data-day-timestamp="1646802000">
                                9
                            </td>
                        <td class="day text-center" data-day-timestamp="1646888400">
                                10
                            </td>
                        <td class="day text-center" data-day-timestamp="1646974800">
                                11
                            </td>
                        <td class="day text-center weekend" data-day-timestamp="1647061200">
                                12
                            </td>
                </tr>
                <tr data-region="month-view-week">
                        <td class="day text-center weekend" data-day-timestamp="1647147600">
                                13
                            </td>
                        <td class="day text-center" data-day-timestamp="1647234000">
                                14
                            </td>
                        <td class="day text-center" data-day-timestamp="1647320400">
                                15
                            </td>
                        <td class="day text-center" data-day-timestamp="1647406800">
                                16
                            </td>
                        <td class="day text-center" data-day-timestamp="1647493200">
                                17
                            </td>
                        <td class="day text-center" data-day-timestamp="1647579600">
                                18
                            </td>
                        <td class="day text-center weekend" data-day-timestamp="1647666000">
                                19
                            </td>
                </tr>
                <tr data-region="month-view-week">
                        <td class="day text-center weekend" data-day-timestamp="1647752400">
                                20
                            </td>
                        <td class="day text-center" data-day-timestamp="1647838800">
                                21
                            </td>
                        <td class="day text-center" data-day-timestamp="1647925200">
                                22
                            </td>
                        <td class="day text-center" data-day-timestamp="1648011600">
                                23
                            </td>
                        <td class="day text-center" data-day-timestamp="1648098000">
                                24
                            </td>
                        <td class="day text-center" data-day-timestamp="1648184400">
                                25
                            </td>
                        <td class="day text-center weekend" data-day-timestamp="1648270800">
                                26
                            </td>
                </tr>
                <tr data-region="month-view-week">
                        <td class="day text-center weekend" data-day-timestamp="1648357200">
                                27
                            </td>
                        <td class="day text-center" data-day-timestamp="1648443600">
                                28
                            </td>
                        <td class="day text-center" data-day-timestamp="1648530000">
                                29
                            </td>
                        <td class="day text-center" data-day-timestamp="1648616400">
                                30
                            </td>
                        <td class="day text-center" data-day-timestamp="1648702800">
                                31
                            </td>
                        <td class="dayblank">&nbsp;</td>
                        <td class="dayblank">&nbsp;</td>
                </tr>
            </tbody>
        </table>
    </div>
</div></div></div><span class="skip-block-to" id="sb-4"></span></aside> 	</div>

	<div class="footerlinks">
    	<div class="row-fluid">
    		<p class="helplink"></p>
    				</div>
        
            		
	<div class="socials row-fluid">
    
        	<div class="span6">
        	<div class="social_contact">
                        <nobr><i class="fa fa-bookmark-o"></i> &nbsp;<a href='https://www.plataformapascal.com/' target="_blank" class="social_contact_web">https://www.plataformapascal.com/</a></nobr>
                                    <nobr><i class="fa fa-envelope-o"></i> &nbsp;<a href='mailto:info@cenuevavision.com'>info@cenuevavision.com</a></nobr>
                        </div>
        </div>
        <div class="span6">
                	<div class="social_icons pull-right">
                                                                                                                                            </div>
        </div>
        
    </div>
    	        
   	</div><div class="logininfo">You are not logged in.</div>	</footer>

    <script type="text/javascript">
//<![CDATA[
var require = {
    baseUrl : 'https://www.plataformapascal.com/NV/lib/requirejs.php/1610057684/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://www.plataformapascal.com/NV/lib/javascript.php/1610057684/lib/jquery/jquery-3.2.1.min',
        jqueryui: 'https://www.plataformapascal.com/NV/lib/javascript.php/1610057684/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://www.plataformapascal.com/NV/lib/javascript.php/1610057684/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/lib/javascript.php/1610057684/lib/requirejs/require.min.js"></script>
<script type="text/javascript">
//<![CDATA[
require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://www.plataformapascal.com/NV/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage("en",{
 "Audio Player": "Audio Player",
 "Video Player": "Video Player",
 "Play": "Play",
 "Pause": "Pause",
 "Replay": "Replay",
 "Current Time": "Current Time",
 "Duration Time": "Duration Time",
 "Remaining Time": "Remaining Time",
 "Stream Type": "Stream Type",
 "LIVE": "LIVE",
 "Loaded": "Loaded",
 "Progress": "Progress",
 "Progress Bar": "Progress Bar",
 "progress bar timing: currentTime={1} duration={2}": "{1} of {2}",
 "Fullscreen": "Fullscreen",
 "Non-Fullscreen": "Non-Fullscreen",
 "Mute": "Mute",
 "Unmute": "Unmute",
 "Playback Rate": "Playback Rate",
 "Subtitles": "Subtitles",
 "subtitles off": "subtitles off",
 "Captions": "Captions",
 "captions off": "captions off",
 "Chapters": "Chapters",
 "Descriptions": "Descriptions",
 "descriptions off": "descriptions off",
 "Audio Track": "Audio Track",
 "Volume Level": "Volume Level",
 "You aborted the media playback": "You aborted the media playback",
 "A network error caused the media download to fail part-way.": "A network error caused the media download to fail part-way.",
 "The media could not be loaded, either because the server or network failed or because the format is not supported.": "The media could not be loaded, either because the server or network failed or because the format is not supported.",
 "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.",
 "No compatible source was found for this media.": "No compatible source was found for this media.",
 "The media is encrypted and we do not have the keys to decrypt it.": "The media is encrypted and we do not have the keys to decrypt it.",
 "Play Video": "Play Video",
 "Close": "Close",
 "Close Modal Dialog": "Close Modal Dialog",
 "Modal Window": "Modal Window",
 "This is a modal window": "This is a modal window",
 "This modal can be closed by pressing the Escape key or activating the close button.": "This modal can be closed by pressing the Escape key or activating the close button.",
 ", opens captions settings dialog": ", opens captions settings dialog",
 ", opens subtitles settings dialog": ", opens subtitles settings dialog",
 ", opens descriptions settings dialog": ", opens descriptions settings dialog",
 ", selected": ", selected",
 "captions settings": "captions settings",
 "subtitles settings": "subititles settings",
 "descriptions settings": "descriptions settings",
 "Text": "Text",
 "White": "White",
 "Black": "Black",
 "Red": "Red",
 "Green": "Green",
 "Blue": "Blue",
 "Yellow": "Yellow",
 "Magenta": "Magenta",
 "Cyan": "Cyan",
 "Background": "Background",
 "Window": "Window",
 "Transparent": "Transparent",
 "Semi-Transparent": "Semi-Transparent",
 "Opaque": "Opaque",
 "Font Size": "Font Size",
 "Text Edge Style": "Text Edge Style",
 "None": "None",
 "Raised": "Raised",
 "Depressed": "Depressed",
 "Uniform": "Uniform",
 "Dropshadow": "Dropshadow",
 "Font Family": "Font Family",
 "Proportional Sans-Serif": "Proportional Sans-Serif",
 "Monospace Sans-Serif": "Monospace Sans-Serif",
 "Proportional Serif": "Proportional Serif",
 "Monospace Serif": "Monospace Serif",
 "Casual": "Casual",
 "Script": "Script",
 "Small Caps": "Small Caps",
 "Reset": "Reset",
 "restore all settings to the default values": "restore all settings to the default values",
 "Done": "Done",
 "Caption Settings Dialog": "Caption Settings Dialog",
 "Beginning of dialog window. Escape will cancel and close the window.": "Beginning of dialog window. Escape will cancel and close the window.",
 "End of dialog window.": "End of dialog window."
});

    });
});;

require(['jquery', 'theme_bootstrapbase/bootstrap'], function($) {
    require(['theme_bootstrapbase/bootstrap'], function() {
        var target = $("#calendar-day-popover-link-1-2022-60-621f6b92b5a0d621f6b92b5c0b1");
        target.popover({
            content: function() {
                var source = target.next().find("> *:not('.hidden')");
                var content = $('<div>');

                if (source.length) {
                    content.html(source.clone(false));
                } else {
                    content.html(target.data('alternate'));
                }

                return content.html();
            }
        });
    });
});
;

require([
    'jquery',
    'core_calendar/selectors',
    'core_calendar/events',
], function(
    $,
    CalendarSelectors,
    CalendarEvents
) {

    $('body').on(CalendarEvents.filterChanged, function(e, data) {
        M.util.js_pending("month-mini-621f6b92b5a0d621f6b92b5c0b1-filterChanged");
        // A filter value has been changed.
        // Find all matching cells in the popover data, and hide them.
        $("#month-mini-2022-March-621f6b92b5a0d621f6b92b5c0b1")
            .find(CalendarSelectors.popoverType[data.type])
            .toggleClass('hidden', !!data.hidden);
        M.util.js_complete("month-mini-621f6b92b5a0d621f6b92b5c0b1-filterChanged");
    });
});
;

require(['jquery', 'core_calendar/calendar_mini'], function($, CalendarMini) {
    CalendarMini.init($("#calendar-month-2022-March-621f6b92b5a0d621f6b92b5c0b1"), !1);
});
;

require(['core/yui'], function(Y) {
    M.util.init_skiplink(Y);
});
;

require(['jquery'], function($) {
    $('#single_select621f6b92b5c0b4').change(function() {
        var ignore = $(this).find(':selected').attr('data-ignore');
        if (typeof ignore === typeof undefined) {
            $('#single_select_f621f6b92b5c0b3').submit();
        }
    });
});
;

;
require(["core/log"], function(amd) { amd.setConfig({"level":"warn"}); });;
require(["core/page_global"], function(amd) { amd.init(); });
});
//]]>
</script>
<script type="text/javascript" src="https://www.plataformapascal.com/NV/theme/javascript.php/lambda/1610135029/footer"></script>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","cancel":"Cancel","morehelp":"More help","loadinghelp":"Loading...","confirm":"Confirm","areyousure":"Are you sure?","closebuttontitle":"Close","unknownerror":"Unknown error"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select"},"admin":{"confirmdeletecomments":"You are about to delete comments, are you sure?","confirmation":"Confirmation"},"block":{"addtodock":"Move this to the dock","undockitem":"Undock this item","dockblock":"Dock {$a} block","undockblock":"Undock {$a} block","undockall":"Undock all","hidedockpanel":"Hide the dock panel","hidepanel":"Hide panel"},"langconfig":{"thisdirectionvertical":"btt"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
(function() {Y.use("moodle-core-dock-loader",function() {M.core.dock.loader.initLoader();
});
Y.use("moodle-filter_mathjaxloader-loader",function() {M.filter_mathjaxloader.configure({"mathjaxconfig":"\nMathJax.Hub.Config({\n    config: [\"Accessible.js\", \"Safe.js\"],\n    errorSettings: { message: [\"!\"] },\n    skipStartupTypeset: true,\n    messageStyle: \"none\"\n});\n","lang":"en"});
});
M.util.help_popups.setup(Y);
Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
M.util.init_block_hider(Y, {"id":"inst58","title":"Plataforma Pascal","preference":"block58hidden","tooltipVisible":"Hide Plataforma Pascal block","tooltipHidden":"Show Plataforma Pascal block"});
M.util.init_block_hider(Y, {"id":"inst59","title":"Nuestra Filosof\u00eda","preference":"block59hidden","tooltipVisible":"Hide Nuestra Filosof\u00eda block","tooltipHidden":"Show Nuestra Filosof\u00eda block"});
M.util.init_block_hider(Y, {"id":"inst57","title":"Calendar","preference":"block57hidden","tooltipVisible":"Hide Calendar block","tooltipHidden":"Show Calendar block"});
 M.util.js_pending('random621f6b92b5c0b8'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random621f6b92b5c0b8'); });
})();
//]]>
</script>

<!--[if lte IE 9]>
<script src="https://www.plataformapascal.com/NV/theme/lambda/javascript/ie/iefix.js"></script>
<![endif]-->

</body>
</html>